# EMP-Hackfest-2024
Group project made during the EMP Hackathon at Redmond Reactor. Sept 7-8
